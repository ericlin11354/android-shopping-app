package com.example.goshopping.presentation.ui.screens.settings

enum class SettingsIntent {
    TOGGLE_ROTATION,
}